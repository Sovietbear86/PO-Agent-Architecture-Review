from dataclasses import dataclass

@dataclass
class SprintMetrics:
    committed_effort: float
    completed_effort: float
    added_after_start_effort: float = 0
    carried_over_effort: float = 0
    throughput: int = 0

    @property
    def predictability(self) -> float:
        return self.completed_effort / self.committed_effort if self.committed_effort else 0.0

    @property
    def scope_change_rate(self) -> float:
        return self.added_after_start_effort / self.committed_effort if self.committed_effort else 0.0
