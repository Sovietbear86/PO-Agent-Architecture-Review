# Обязательные тесты

1. Сопоставление login/email с S21.
2. Расчет committed scope.
3. Scope change и carryover.
4. История статусов и cycle time.
5. Учет allocation и отсутствий.
6. Подбор кандидатов по компетенциям.
7. Маскирование email и логинов в общих отчетах.
