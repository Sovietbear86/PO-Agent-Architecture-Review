# Skill: Flow Metrics

Считай throughput, cycle time, lead time, WIP, blocked time, review time, testing time, aging WIP и flow efficiency.

Главная цель — показать, где работа ждет.
