# Skill: Sprint Health

Анализируй committed scope, completed scope, scope change, carryover, блокеры, aging WIP, незапланированную работу и связь с релизом.

Выход:
- статус green/yellow/red;
- причины;
- вероятность завершения;
- задачи, требующие внимания;
- рекомендации.
