from pathlib import Path
import yaml

required = [
    "AGENT.md",
    "TEAM_STRUCTURE_TEMPLATE.md",
    "config/team_members.template.yaml",
    "config/products.yaml",
    "config/metrics.yaml",
    "config/thresholds.yaml",
]

for name in required:
    if not Path(name).exists():
        raise SystemExit(f"Отсутствует файл: {name}")

for path in Path("config").glob("*.yaml"):
    with path.open("r", encoding="utf-8") as f:
        yaml.safe_load(f)

print("Конфигурация корректна.")
