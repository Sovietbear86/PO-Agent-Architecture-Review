from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    s21_base_url: str
    s21_api_token: str = ""
    s21_verify_tls: bool = True

    notification_default_recipient: str = "kalachanov.v.v@sbertech.ru"
    notification_timezone: str = "Europe/Moscow"
    notification_read_only: bool = True
    notification_dry_run: bool = True
    notification_max_emails_per_day: int = 10
    notification_cooldown_hours: int = 24
    notification_quiet_hours_start: str = "20:00"
    notification_quiet_hours_end: str = "08:00"

    mail_transport: str = "disabled"
    mail_from: str = "s21-agent@sbertech.ru"
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_use_tls: bool = True


settings = Settings()
