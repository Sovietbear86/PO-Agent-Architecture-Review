from __future__ import annotations

import smtplib
from email.message import EmailMessage as StdEmailMessage

from s21_notification_agent.config import settings
from s21_notification_agent.models.email import EmailMessage


class EmailSender:
    def send(self, message: EmailMessage) -> None:
        if settings.notification_dry_run or settings.mail_transport == "disabled":
            print("[DRY RUN]")
            print(message.model_dump_json(indent=2))
            return

        if settings.mail_transport != "smtp":
            raise NotImplementedError(
                "Подключите разрешенный корпоративный email-коннектор."
            )

        if not settings.smtp_host:
            raise RuntimeError("SMTP_HOST не задан.")

        mail = StdEmailMessage()
        mail["From"] = settings.mail_from
        mail["To"] = ", ".join(str(address) for address in message.to)
        mail["Subject"] = message.subject
        mail.set_content(message.text_body)
        if message.html_body:
            mail.add_alternative(message.html_body, subtype="html")

        with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=30) as smtp:
            if settings.smtp_use_tls:
                smtp.starttls()
            if settings.smtp_username:
                smtp.login(settings.smtp_username, settings.smtp_password)
            smtp.send_message(mail)
