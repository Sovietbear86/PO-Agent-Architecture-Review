from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field


class Priority(StrEnum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class DeliveryMode(StrEnum):
    IMMEDIATE = "immediate"
    DAILY_DIGEST = "daily_digest"
    WEEKLY_DIGEST = "weekly_digest"
    SUPPRESS = "suppress"


class NotificationEvent(BaseModel):
    event_id: str
    event_type: str
    priority: Priority
    task_id: str | None = None
    title: str
    summary: str
    impact: str = ""
    recommended_action: str = ""
    source_url: str | None = None
    occurred_at: datetime
    attributes: dict = Field(default_factory=dict)


class DeliveryDecision(BaseModel):
    mode: DeliveryMode
    reason: str
    send_after: datetime | None = None
