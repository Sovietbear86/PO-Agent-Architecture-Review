from pydantic import BaseModel, EmailStr, Field


class EmailMessage(BaseModel):
    to: list[EmailStr]
    subject: str
    text_body: str
    html_body: str | None = None
    headers: dict[str, str] = Field(default_factory=dict)
