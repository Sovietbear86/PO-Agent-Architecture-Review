from s21_notification_agent.models.email import EmailMessage
from s21_notification_agent.models.events import NotificationEvent


class EmailComposer:
    def compose_alert(self, event: NotificationEvent, recipient: str) -> EmailMessage:
        subject = f"[S21][{event.priority.value.upper()}] {event.title}"
        body = (
            f"{event.summary}\n\n"
            f"Влияние: {event.impact or 'не указано'}\n"
            f"Рекомендуемое действие: {event.recommended_action or 'проверить задачу'}\n"
            f"Задача: {event.task_id or 'не указана'}\n"
            f"Источник: {event.source_url or 'не указан'}\n"
        )
        return EmailMessage(to=[recipient], subject=subject, text_body=body)

    def compose_digest(
        self,
        events: list[NotificationEvent],
        recipient: str,
        title: str = "Утренняя сводка",
    ) -> EmailMessage:
        lines = [title, ""]
        for index, event in enumerate(events, start=1):
            lines.extend([
                f"{index}. {event.title}",
                f"   {event.summary}",
                f"   Действие: {event.recommended_action or 'проверить задачу'}",
                f"   Ссылка: {event.source_url or 'не указана'}",
                "",
            ])
        return EmailMessage(
            to=[recipient],
            subject=f"[S21] {title}",
            text_body="\n".join(lines),
        )
