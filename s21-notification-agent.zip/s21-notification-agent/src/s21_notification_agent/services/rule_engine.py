from s21_notification_agent.models.events import (
    DeliveryDecision,
    DeliveryMode,
    NotificationEvent,
    Priority,
)


class RuleEngine:
    def decide(self, event: NotificationEvent) -> DeliveryDecision:
        if event.priority == Priority.CRITICAL:
            return DeliveryDecision(
                mode=DeliveryMode.IMMEDIATE,
                reason="Критическое событие требует немедленного внимания.",
            )
        if event.priority in {Priority.HIGH, Priority.MEDIUM}:
            return DeliveryDecision(
                mode=DeliveryMode.DAILY_DIGEST,
                reason="Событие важно, но может быть включено в дневную сводку.",
            )
        return DeliveryDecision(
            mode=DeliveryMode.WEEKLY_DIGEST,
            reason="Информационное событие включается в недельный обзор.",
        )
