from datetime import datetime, timedelta, timezone


class InMemoryDeduplicationStore:
    def __init__(self) -> None:
        self._sent: dict[str, datetime] = {}

    def should_send(self, fingerprint: str, cooldown_hours: int) -> bool:
        sent_at = self._sent.get(fingerprint)
        if sent_at is None:
            return True
        return datetime.now(timezone.utc) - sent_at >= timedelta(hours=cooldown_hours)

    def mark_sent(self, fingerprint: str) -> None:
        self._sent[fingerprint] = datetime.now(timezone.utc)
