import hashlib

from s21_notification_agent.config import settings
from s21_notification_agent.connectors.email_sender import EmailSender
from s21_notification_agent.models.events import DeliveryMode, NotificationEvent
from s21_notification_agent.services.deduplication import InMemoryDeduplicationStore
from s21_notification_agent.services.email_composer import EmailComposer
from s21_notification_agent.services.rule_engine import RuleEngine


class NotificationOrchestrator:
    def __init__(self) -> None:
        self.rules = RuleEngine()
        self.dedup = InMemoryDeduplicationStore()
        self.composer = EmailComposer()
        self.sender = EmailSender()

    def process(self, event: NotificationEvent) -> str:
        decision = self.rules.decide(event)
        if decision.mode != DeliveryMode.IMMEDIATE:
            return f"queued:{decision.mode.value}"

        fingerprint = hashlib.sha256(
            f"{event.event_type}|{event.task_id}|{event.summary}".encode()
        ).hexdigest()

        if not self.dedup.should_send(
            fingerprint, settings.notification_cooldown_hours
        ):
            return "suppressed:duplicate"

        message = self.composer.compose_alert(
            event, settings.notification_default_recipient
        )
        self.sender.send(message)
        self.dedup.mark_sent(fingerprint)
        return "sent"
