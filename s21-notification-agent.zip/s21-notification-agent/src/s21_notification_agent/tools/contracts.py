from datetime import datetime
from pydantic import BaseModel, EmailStr, Field


class CreateReminderInput(BaseModel):
    task_id: str | None = None
    reason: str
    due_at: datetime | None = None
    recipient: EmailStr = "kalachanov.v.v@sbertech.ru"
    priority: str = "medium"


class SendDigestInput(BaseModel):
    recipient: EmailStr = "kalachanov.v.v@sbertech.ru"
    event_ids: list[str] = Field(default_factory=list)


class UpdateWatchRuleInput(BaseModel):
    rule_name: str
    enabled: bool
    parameters: dict = Field(default_factory=dict)
