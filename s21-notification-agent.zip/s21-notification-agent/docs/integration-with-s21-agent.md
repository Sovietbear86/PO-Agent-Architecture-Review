# Интеграция с S21 Task Intelligence Agent

Notification Agent не должен повторно реализовывать весь анализ S21.

Рекомендуемый контракт:

```json
{
  "event_id": "uuid",
  "event_type": "overdue_task",
  "priority": "high",
  "task_id": "S21-12345",
  "title": "Просрочена критическая задача",
  "summary": "Срок прошел 3 дня назад",
  "impact": "Риск релиза 2.4.0",
  "recommended_action": "Запросить план устранения",
  "source_url": "https://...",
  "occurred_at": "2026-07-31T09:00:00+03:00"
}
```

S21 Task Agent формирует события и аналитику.
Notification Agent решает, когда и как уведомлять.
