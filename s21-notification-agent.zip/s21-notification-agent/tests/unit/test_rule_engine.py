from datetime import datetime, timezone

from s21_notification_agent.models.events import (
    DeliveryMode,
    NotificationEvent,
    Priority,
)
from s21_notification_agent.services.rule_engine import RuleEngine


def test_critical_is_immediate() -> None:
    event = NotificationEvent(
        event_id="1",
        event_type="blocker",
        priority=Priority.CRITICAL,
        title="Blocker",
        summary="Critical event",
        occurred_at=datetime.now(timezone.utc),
    )
    assert RuleEngine().decide(event).mode == DeliveryMode.IMMEDIATE
