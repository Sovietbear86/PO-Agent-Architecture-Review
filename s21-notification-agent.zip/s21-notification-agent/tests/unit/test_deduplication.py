from s21_notification_agent.services.deduplication import InMemoryDeduplicationStore


def test_duplicate_is_suppressed() -> None:
    store = InMemoryDeduplicationStore()
    assert store.should_send("x", 24)
    store.mark_sent("x")
    assert not store.should_send("x", 24)
