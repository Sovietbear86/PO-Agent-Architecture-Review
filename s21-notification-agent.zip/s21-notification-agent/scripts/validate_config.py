from pathlib import Path
import yaml

for path in Path("config").glob("*.yaml"):
    with path.open("r", encoding="utf-8") as fh:
        yaml.safe_load(fh)

required = [
    Path("AGENT.md"),
    Path("config/agent.yaml"),
    Path("config/rules.yaml"),
]
for path in required:
    if not path.exists():
        raise SystemExit(f"Отсутствует файл: {path}")

print("Конфигурация корректна.")
