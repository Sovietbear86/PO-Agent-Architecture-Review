from datetime import datetime, timezone

from s21_notification_agent.models.events import NotificationEvent, Priority
from s21_notification_agent.services.orchestrator import NotificationOrchestrator


event = NotificationEvent(
    event_id="demo-1",
    event_type="release_blocker",
    priority=Priority.CRITICAL,
    task_id="S21-12345",
    title="Блокер релиза 2.4.0",
    summary="Критическая задача просрочена на 3 дня.",
    impact="Риск переноса релиза.",
    recommended_action="Запросить актуальный статус и план устранения блокера.",
    source_url="https://s21.example.corp/browse/S21-12345",
    occurred_at=datetime.now(timezone.utc),
)

print(NotificationOrchestrator().process(event))
